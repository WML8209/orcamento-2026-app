import streamlit as st
from core import db, exportar
from core.formatos import fmt_num_br, fmt_data_br, mes_pt
from core.tabela_html import gerar_html_tabela_simples

db.init_db()
st.title("📋 PCA 2026")
st.caption(
    "Plano de Contratações Anual — preenchido automaticamente pelas Despesas Gerais "
    "(Nova Contratação / Renovação / Sem Renovação)."
)

df = db.carregar_pca_2026()

if df.empty:
    st.info("Nenhum item de PCA registrado ainda. Itens são criados automaticamente ao lançar Contratações/Renovações.")
else:
    colunas = [
        ("item", "Item"), ("descricao_objeto", "Descrição do Objeto"), ("justificativa", "Justificativa"),
        ("contratacao_renovacao", "Contratação/Renovação"), ("data_fmt", "Data Contr./Renov."),
        ("conta_contabil", "Conta Contábil"), ("descricao", "Descrição da Conta"),
        ("projeto", "Projeto"), ("uo", "UO"), ("valor_fmt", "Valor p/ Orçamento 2026"),
        ("grau_prioridade", "Grau de Prioridade"), ("classificacao", "Classificação"), ("mes_fmt", "Mês"),
    ]
    linhas = []
    for _, row in df.iterrows():
        linhas.append({
            "item": row["item"], "descricao_objeto": row["descricao_objeto"], "justificativa": row["justificativa"] or "—",
            "contratacao_renovacao": row["contratacao_renovacao"], "data_fmt": fmt_data_br(row["data_contratacao_renovacao"]),
            "conta_contabil": row["conta_contabil"], "descricao": row["descricao"],
            "projeto": row["projeto"], "uo": row["uo"], "valor_fmt": fmt_num_br(row["valor_orcamento_2026"]),
            "grau_prioridade": row["grau_prioridade"] or "—", "classificacao": row["classificacao"] or "—",
            "mes_fmt": mes_pt(row["mes"]),
        })
    html_tabela = gerar_html_tabela_simples(colunas, linhas, alinhar_direita={"valor_fmt"})
    st.iframe(html_tabela, height=min(120 + len(linhas) * 36, 500))

    st.divider()
    st.subheader("Editar Justificativa / Grau de Prioridade / Classificação")
    st.caption("Conta, Descrição e Valor só mudam se você editar o lançamento correspondente em Projeção Orçamento.")

    opcoes_item = df["item"].tolist()
    item_sel = st.selectbox(
        "Item", opcoes_item,
        format_func=lambda i: f"Item {i} — {df[df['item']==i]['descricao_objeto'].iloc[0]}",
    )
    linha_sel = df[df["item"] == item_sel].iloc[0]

    c1, c2 = st.columns(2)
    with c1:
        nova_justificativa = st.text_area(
            "Justificativa", value=linha_sel["justificativa"] or "", height=120,
            help="Pode digitar ou colar o texto aqui.",
        )
        opcoes_grau = ["", "Baixo", "Médio", "Alto"]
        grau_atual = linha_sel["grau_prioridade"] if linha_sel["grau_prioridade"] in opcoes_grau else ""
        novo_grau = st.selectbox("Grau de Prioridade", opcoes_grau, index=opcoes_grau.index(grau_atual))
    with c2:
        nova_classificacao = st.text_input("Classificação", value=linha_sel["classificacao"] or "")

    if st.button("💾 Salvar edições", type="primary"):
        db.atualizar_pca_editaveis(int(linha_sel["id"]), nova_justificativa, novo_grau, nova_classificacao)
        st.success(f"Item {item_sel} atualizado.")
        st.rerun()

    st.divider()
    if st.button("📊 Exportar para Excel"):
        caminho = exportar.gerar_excel_pca(df)
        with open(caminho, "rb") as f:
            st.download_button("⬇️ Baixar Excel gerado", f, file_name=caminho.name,
                                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        st.success(f"Excel gerado em: {caminho}")
