import streamlit as st
from core import db, exportar
from core.formatos import fmt_num_br, fmt_data_br
from core.tabela_html import gerar_html_tabela_simples

db.init_db()
st.title("🧮 Memória de Cálculo")
st.caption("Equivalente à aba 'TemporáriaPDF' — memórias de cálculo de Diárias e Passagens, com exportação em PDF por lançamento.")

vivo = db.carregar_orcamento_2026()
diarias = vivo[vivo["origem"] == "diarias"] if not vivo.empty else vivo

if diarias.empty:
    st.info("Nenhum lançamento de Diárias e Passagens registrado ainda.")
else:
    resumo = (
        diarias.groupby("indice")
        .agg(projeto=("projeto", "first"), subprojeto=("subprojeto", "first"),
             descricao=("descricao", "first"), data=("data", "first"),
             memoria_calculo=("memoria_calculo", "first"), valor_total=("valor", "sum"))
        .reset_index()
        .sort_values("indice", ascending=False)
    )

    colunas = [
        ("projeto", "Projeto"), ("subprojeto", "SubProjeto"), ("descricao", "Descrição"),
        ("data_fmt", "Data"), ("valor_fmt", "Valor Total"),
    ]
    linhas = []
    for _, row in resumo.iterrows():
        linhas.append({
            "projeto": row["projeto"], "subprojeto": row["subprojeto"], "descricao": row["descricao"],
            "data_fmt": fmt_data_br(row["data"]), "valor_fmt": fmt_num_br(row["valor_total"]),
        })
    html_tabela = gerar_html_tabela_simples(colunas, linhas, alinhar_direita={"valor_fmt"})
    st.iframe(html_tabela, height=min(120 + len(linhas) * 34, 400))

    st.divider()
    for _, row in resumo.iterrows():
        titulo = f"{row['projeto']} - {row['subprojeto']} — {row['descricao'] or '(sem descrição)'} ({fmt_num_br(row['valor_total'])})"
        with st.expander(titulo):
            st.text(row["memoria_calculo"] or "(sem memória de cálculo registrada)")
            if st.button("📄 Exportar PDF", key=f"pdf_mem_{row['indice']}"):
                caminho = exportar.gerar_pdf_memoria(
                    int(row["indice"]), row["projeto"], row["subprojeto"], row["descricao"], row["memoria_calculo"]
                )
                with open(caminho, "rb") as f:
                    st.download_button("⬇️ Baixar PDF gerado", f, file_name=caminho.name,
                                        mime="application/pdf", key=f"dl_mem_{row['indice']}")
                st.success(f"PDF gerado em: {caminho}")
