import streamlit as st
from core import agregacao, db
from core.dialogs import dialog_diarias, dialog_despesas, abrir_edicao
from core.formatos import fmt_num_br, fmt_data_br
from core.tabela_html import gerar_html_tabela_dinamica, gerar_html_tabela_simples
from core.config import ANO_ORCAMENTO

db.init_db()

st.title(f"📈 Elaboração do Orçamento de {ANO_ORCAMENTO}")

completo = agregacao.montar_orcamento_completo()
coordenadorias = agregacao.coordenadorias_disponiveis(completo)
coordenadoria_atual = st.session_state.get("projecao_coordenadoria", coordenadorias[0] if coordenadorias else None)

# --- Cabeçalho: coordenadoria + valor do ano corrente, botões de lançamento ---
c_valor, c_btn1, c_btn2 = st.columns([3, 1.4, 1.4])
with c_valor:
    if coordenadoria_atual:
        arvore_ano_atual = agregacao.montar_arvore_multi_ano(completo, coordenadoria_atual, [ANO_ORCAMENTO])
        valor_ano = arvore_ano_atual["totais"].get(ANO_ORCAMENTO, {}).get("orcamento", 0.0)
        st.markdown(
            f"<span style='font-size:26px;color:#1f4e8c;font-weight:700'>{coordenadoria_atual}</span>"
            f"&nbsp;&nbsp;&nbsp;"
            f"<span style='font-size:26px;color:#1f4e8c;font-weight:700'>{fmt_num_br(valor_ano)}</span>",
            unsafe_allow_html=True,
        )
with c_btn1:
    if st.button("📄 Registrar Despesas Gerais", use_container_width=True):
        dialog_despesas()
with c_btn2:
    if st.button("🧳 Registrar Diárias e Passagens", use_container_width=True):
        dialog_diarias()

st.divider()

if completo.empty or not coordenadorias:
    st.info("Ainda não há dados. Verifique se bases.xlsx / orcamento_historico.xlsx existem e/ou registre lançamentos pelos botões acima.")
else:
    st.selectbox("Coordenadoria", coordenadorias, key="projecao_coordenadoria")
    coordenadoria = st.session_state["projecao_coordenadoria"]

    anos = agregacao.anos_disponiveis(completo)
    arvore = agregacao.montar_arvore_multi_ano(completo, coordenadoria, anos)

    if not arvore["projetos"]:
        st.info(f"Nenhum lançamento para {coordenadoria}.")
    else:
        n_linhas = sum(1 + len(p["subprojetos"]) + sum(len(s["contas"]) for s in p["subprojetos"]) for p in arvore["projetos"])
        altura = 110 + (n_linhas + 1) * 38
        html_tabela = gerar_html_tabela_dinamica(arvore, ANO_ORCAMENTO)
        st.iframe(html_tabela, height=min(altura, 900))

    st.divider()
    st.subheader("Lançamentos de 2026 (consulta / edição / exclusão)")
    vivo = db.carregar_orcamento_2026()
    if vivo.empty:
        st.info("Nenhum lançamento de 2026 ainda.")
    else:
        colunas = [
            ("projeto", "Projeto"), ("subprojeto", "SubProjeto"), ("conta", "Conta"),
            ("descricao", "Descrição"), ("data", "Data"), ("valor", "Valor"), ("origem", "Origem"),
        ]
        linhas = []
        for _, row in vivo.iterrows():
            linhas.append({
                "projeto": row["projeto"], "subprojeto": row["subprojeto"], "conta": row["conta"],
                "descricao": row["descricao"], "data": fmt_data_br(row["data"]),
                "valor": fmt_num_br(row["valor"]), "origem": row["origem"],
            })
        html_lista = gerar_html_tabela_simples(colunas, linhas, alinhar_direita={"valor"})
        st.iframe(html_lista, height=min(120 + len(linhas) * 34, 500))

        opcoes_indice = sorted(vivo["indice"].unique().tolist(), reverse=True)
        idx = st.selectbox(
            "Selecione o lançamento", opcoes_indice,
            format_func=lambda i: f"Lançamento {opcoes_indice.index(i) + 1} — {vivo[vivo['indice']==i]['descricao'].iloc[0] or '(sem descrição)'}",
        )
        cA, cB = st.columns(2)
        with cA:
            if st.button("✏️ Editar lançamento selecionado", use_container_width=True):
                abrir_edicao(int(idx))
        with cB:
            if st.button("🗑️ Excluir lançamento selecionado", type="primary", use_container_width=True):
                db.excluir_por_indice(int(idx))
                st.success("Lançamento excluído. A projeção acima já está atualizada.")
                st.rerun()
