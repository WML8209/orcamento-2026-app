import streamlit as st
from core import agregacao, exportar, db
from core.formatos import fmt_num_br
from core.tabela_html import montar_arvore_resumo, gerar_html_arvore_resumo
from core.config import ANO_ORCAMENTO

db.init_db()
st.title("🧾 Resumo")
st.caption(f"Consolidado de {ANO_ORCAMENTO} por Coordenadoria — Projeto, SubProjeto, Descrição, Conta e Valor.")

completo = agregacao.montar_orcamento_completo()

if completo.empty:
    st.info("Ainda não há dados para montar o resumo.")
else:
    coordenadorias = agregacao.coordenadorias_disponiveis(completo)
    if not coordenadorias:
        st.warning("Nenhuma Coordenadoria encontrada — confira a aba SubProjetos em bases.xlsx.")
    else:
        coordenadoria = st.selectbox("Coordenadoria", coordenadorias)
        arvore = montar_arvore_resumo(completo, coordenadoria, ANO_ORCAMENTO)

        if not arvore["projetos"]:
            st.info(f"Nenhum lançamento de {ANO_ORCAMENTO} para {coordenadoria}.")
        else:
            n_linhas = sum(1 + len(p["subprojetos"]) + sum(len(s["contas"]) for s in p["subprojetos"]) for p in arvore["projetos"])
            altura = 90 + (n_linhas + 1) * 38
            st.iframe(gerar_html_arvore_resumo(arvore), height=min(altura, 700))

            st.metric("Total Geral", "R$ " + fmt_num_br(arvore["total"]))

            if st.button("📄 Exportar PDF"):
                # Achata a árvore para o formato tabular que o exportador espera
                import pandas as pd
                linhas_flat = []
                for p in arvore["projetos"]:
                    for s in p["subprojetos"]:
                        for c in s["contas"]:
                            linhas_flat.append({
                                "Projeto": p["descricao"], "SubProjeto": f"{s['subprojeto']} - {s['nome']}",
                                "Descrição": c.get("descricao") or "", "Conta": c["conta"], "Total": c["valor"],
                            })
                resumo_df = pd.DataFrame(linhas_flat)
                caminho = exportar.gerar_pdf_resumo(resumo_df, coordenadoria, ANO_ORCAMENTO)
                with open(caminho, "rb") as f:
                    st.download_button("⬇️ Baixar PDF gerado", f, file_name=caminho.name, mime="application/pdf")
                st.success(f"PDF gerado em: {caminho}")
