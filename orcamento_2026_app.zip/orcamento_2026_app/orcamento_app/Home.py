import streamlit as st
from core import db

st.set_page_config(page_title="Orçamento 2026", page_icon="📊", layout="wide")
db.init_db()


def pagina_inicio():
    st.title("📊 Sistema de Elaboração do Orçamento 2026")
    st.markdown("""
Substitui as macros VBA da planilha original por telas equivalentes, mantendo
a mesma lógica de cálculo e a mesma estrutura de dados (histórico fixo +
lançamentos de 2026, agrupados por Índice).

Use o menu à esquerda para navegar entre **Projeção Orçamento 2026**, **Resumo**,
**Memória de Cálculo** e **PCA 2026**. Os lançamentos (Diárias/Passagens e Despesas
Gerais) são feitos por botões que abrem uma caixa de diálogo, direto na tela de
Projeção — assim dá para lançar e já ver o impacto no orçamento sem trocar de tela.
""")
    st.divider()
    st.subheader("Status dos arquivos de dados")
    from core.config import BASES_XLSX, ORCAMENTO_HISTORICO_XLSX, ORCAMENTO_2026_DB

    def _status(path, nome):
        if path.exists():
            st.success(f"✅ {nome}: `{path}`")
        else:
            st.error(f"⚠️ {nome} não encontrado em: `{path}` — ajuste em core/config.py.")

    _status(BASES_XLSX, "Bases fixas (bases.xlsx)")
    _status(ORCAMENTO_HISTORICO_XLSX, "Orçamento histórico (orcamento_historico.xlsx)")
    st.info(f"🗄️ Banco de lançamentos 2026 (SQLite): `{ORCAMENTO_2026_DB}`  \n"
            "Criado/atualizado automaticamente pelo próprio app.")


inicio = st.Page(pagina_inicio, title="Início", icon="🏠", default=True)
projecao = st.Page("pages/projecao.py", title="Projeção Orçamento 2026", icon="📈")
resumo = st.Page("pages/resumo.py", title="Resumo", icon="🧾")
memoria = st.Page("pages/memoria.py", title="Memória de Cálculo", icon="🧮")
pca = st.Page("pages/pca.py", title="PCA 2026", icon="📋")

pg = st.navigation([inicio, projecao, resumo, memoria, pca])
pg.run()
