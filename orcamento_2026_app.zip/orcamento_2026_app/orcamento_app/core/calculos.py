"""
Réplica das regras de cálculo das duas macros originais:
  - FormDepad            -> calcular_diarias_passagens()
  - FormDespesasGerais   -> calcular_despesas_gerais()

Os valores unitários de diária/passagem vêm da aba 'Parâmetros Diária' (ver
core/loaders.py), em vez de estarem fixos no código como estavam na macro.
"""
from dataclasses import dataclass, field
from datetime import date
import pandas as pd

from core import loaders
from core.formatos import fmt_brl, fmt_num_br  # noqa: F401 (reexportado para quem já importa daqui)

CODIGOS_CONTA = {
    ("Funcionário", "diaria"): "63130203001",
    ("Funcionário", "passagem"): "63130204001",
    ("Conselheiro", "diaria"): "63130203002",
    ("Conselheiro", "passagem"): "63130204002",
    ("Colaborador", "diaria"): "63130203003",
    ("Colaborador", "passagem"): "63130204003",
    ("Colaborador Exame", "diaria"): "63130203003",
    ("Colaborador Exame", "passagem"): "63130204003",
}
CODIGO_AUXILIO = "63130206001"

CATEGORIAS = ["Funcionário", "Conselheiro", "Colaborador", "Colaborador Exame"]


def _taxa(tabela_param: pd.DataFrame, cargo: str, trecho: str):
    linha = tabela_param[(tabela_param["Cargo"] == cargo) & (tabela_param["Tipo Trecho"] == trecho)]
    if linha.empty:
        return None, None
    diaria = float(linha.iloc[0]["Valor Diária (R$)"])
    passagem_raw = linha.iloc[0]["Valor Passagem (R$)"]
    try:
        passagem = float(passagem_raw)
    except (TypeError, ValueError):
        passagem = None  # ex.: Colaborador Exame Internacional, não aplicável
    return diaria, passagem


@dataclass
class CategoriaInput:
    categoria: str
    qtd_pessoas: float = 0
    qtd_reunioes: float = 0
    qtd_diarias: float = 0


@dataclass
class ResultadoDiarias:
    total_diaria: float = 0.0
    total_passagem: float = 0.0
    total_auxilio: float = 0.0
    memoria: str = ""
    linhas_orcamento: list = field(default_factory=list)  # prontas p/ gravar no banco
    erros: list = field(default_factory=list)


def calcular_diarias_passagens(
    tipo_trecho: str,             # "Nacional" | "Internacional"
    incluir_passagem: bool,
    categorias: list[CategoriaInput],
    projeto: str,
    subprojeto: str,
    descricao: str,
) -> ResultadoDiarias:
    tabela_param = loaders.parametros_diaria()
    valor_aux = loaders.valor_auxilio_deslocamento()

    r = ResultadoDiarias()
    memoria_partes = []

    for cat_input in categorias:
        if cat_input.qtd_pessoas <= 0 and cat_input.qtd_reunioes <= 0 and cat_input.qtd_diarias <= 0:
            continue  # categoria não preenchida

        if cat_input.categoria == "Colaborador Exame" and tipo_trecho == "Internacional":
            r.erros.append("Colaborador - Exame de Suficiência não é permitido para Internacional.")
            continue

        v_diaria, v_passagem = _taxa(tabela_param, cat_input.categoria, tipo_trecho)
        if v_diaria is None:
            r.erros.append(f"Não há parâmetro de diária cadastrado para {cat_input.categoria} / {tipo_trecho}.")
            continue

        qp, qr, qd = cat_input.qtd_pessoas, cat_input.qtd_reunioes, cat_input.qtd_diarias
        vdiaria_tot = v_diaria * qp * qr * qd
        vpass_tot = 0.0
        vaux_tot = 0.0
        if incluir_passagem and v_passagem is not None:
            vpass_tot = v_passagem * qp * qr
            vaux_tot = valor_aux * qp * qr

        r.total_diaria += vdiaria_tot
        r.total_passagem += vpass_tot
        r.total_auxilio += vaux_tot

        sub = (f"{'Diária e Passagem' if incluir_passagem else 'Somente Diária'} > Tipo de Trecho: {tipo_trecho}\n"
               f"{qp:g} {cat_input.categoria}(s), para {qr:g} reuniões, com {qd:g} diárias\n"
               f"Diária: {qd:g} * {fmt_brl(v_diaria)} * {qp:g} * {qr:g} = {fmt_brl(vdiaria_tot)}\n")
        if incluir_passagem and v_passagem is not None:
            sub += (f"Passagem: {qp:g} * {fmt_brl(v_passagem)} * {qr:g} = {fmt_brl(vpass_tot)}\n"
                    f"Auxílio Deslocamento: {qp:g} * {fmt_brl(valor_aux)} * {qr:g} = {fmt_brl(vaux_tot)}\n")
        memoria_partes.append(sub)

        # Linhas prontas para gravação (índice é preenchido depois, no chamador)
        if vdiaria_tot > 0:
            r.linhas_orcamento.append(dict(
                projeto=projeto, subprojeto=subprojeto,
                conta=CODIGOS_CONTA[(cat_input.categoria, "diaria")],
                valor=vdiaria_tot, descricao=descricao, origem="diarias",
            ))
        if vpass_tot > 0:
            r.linhas_orcamento.append(dict(
                projeto=projeto, subprojeto=subprojeto,
                conta=CODIGOS_CONTA[(cat_input.categoria, "passagem")],
                valor=vpass_tot, descricao=descricao, origem="diarias",
            ))
        if vaux_tot > 0:
            r.linhas_orcamento.append(dict(
                projeto=projeto, subprojeto=subprojeto,
                conta=CODIGO_AUXILIO,
                valor=vaux_tot, descricao=descricao, origem="diarias",
            ))

    r.memoria = "Memória de Cálculo:\n" + "\n".join(memoria_partes)
    return r


@dataclass
class ResultadoDespesaGeral:
    valor_proporcional: float = 0.0
    valor_apos_renovacao: float = 0.0
    valor_total: float = 0.0
    meses_vigencia: int = 0
    meses_em_2026: int = 0
    situacao_pca: str = ""
    erro: str | None = None


def calcular_despesas_gerais(
    tipo: str,  # "Nova Contratação" | "Renovação" | "Sem Renovação" | "Demais Despesas"
    valor_total: float | None,
    inicio_vigencia: date | None,
    fim_vigencia: date | None,
    mes_valor_antigo: int = 0,
    mes_valor_novo: int = 0,
    valor_diferente: float | None = None,
) -> ResultadoDespesaGeral:
    res = ResultadoDespesaGeral()
    reajuste = loaders.percentual_reajuste_renovacao()

    if tipo == "Demais Despesas":
        # Só o valor proporcional (informado direto) importa
        res.valor_proporcional = valor_diferente or 0.0
        res.valor_total = res.valor_proporcional
        return res

    if not inicio_vigencia or not fim_vigencia or valor_total is None:
        res.erro = "Informe vigência (início/fim) e valor total."
        return res

    meses_vigencia = _diff_meses(inicio_vigencia, fim_vigencia)
    if meses_vigencia < 1:
        meses_vigencia = 1
    res.meses_vigencia = meses_vigencia

    if tipo == "Nova Contratação":
        fim_ano = date(2026, 12, 31)
        if fim_vigencia <= fim_ano:
            meses_2026 = _diff_meses(inicio_vigencia, fim_vigencia)
        elif inicio_vigencia >= date(2027, 1, 1):
            meses_2026 = 0
        else:
            meses_2026 = _diff_meses(inicio_vigencia, fim_ano) + 1
        meses_2026 = max(meses_2026, 0)
        res.meses_em_2026 = meses_2026
        res.valor_proporcional = (valor_total / meses_vigencia) * meses_2026
        res.valor_apos_renovacao = 0.0
        res.situacao_pca = "Nova Contratação"

    elif tipo == "Sem Renovação":
        res.valor_proporcional = (valor_total / meses_vigencia) * mes_valor_antigo
        res.valor_apos_renovacao = 0.0
        res.situacao_pca = "Vigente" if fim_vigencia > date(2026, 12, 31) else "Sem Prorrogação"

    elif tipo == "Renovação":
        res.valor_proporcional = (valor_total / meses_vigencia) * mes_valor_antigo
        res.valor_apos_renovacao = ((valor_total * (1 + reajuste)) / meses_vigencia) * mes_valor_novo
        res.situacao_pca = "Renovação"

    if valor_diferente is not None:
        res.valor_total = valor_diferente
    else:
        res.valor_total = res.valor_proporcional + res.valor_apos_renovacao

    return res


def _diff_meses(d1: date, d2: date) -> int:
    """Equivalente a DateDiff('m', d1, d2) do VBA: diferença de meses de calendário."""
    return (d2.year - d1.year) * 12 + (d2.month - d1.month)
