"""
Caixas de diálogo (modais) para os dois lançamentos, chamadas por botão a
partir de qualquer página — em vez de serem páginas fixas no menu lateral.
Suportam edição: dialog_editar() detecta o tipo do lançamento salvo e abre
o formulário certo, já preenchido.
"""
import streamlit as st
from core import db
from core.forms_diarias import render_form_diarias
from core.forms_despesas import render_form_despesas


@st.dialog("🧳 Lançar Diárias e Passagens", width="large")
def dialog_diarias(indice_editar=None):
    render_form_diarias(indice_editar)


@st.dialog("📄 Lançar Despesas Gerais", width="large")
def dialog_despesas(indice_editar=None):
    render_form_despesas(indice_editar)


def abrir_edicao(indice: int):
    """Detecta o tipo do lançamento (diárias ou despesas gerais) e abre o diálogo certo, preenchido."""
    meta = db.carregar_meta(indice)
    if not meta:
        st.warning("Não encontrei os dados originais desse lançamento para editar (foi criado antes desta versão).")
        return
    if meta["tipo"] == "diarias":
        dialog_diarias(indice_editar=indice)
    else:
        dialog_despesas(indice_editar=indice)


def botoes_lancamento():
    """Renderiza os dois botões que abrem os diálogos. Chame no topo de qualquer página."""
    c1, c2 = st.columns(2)
    with c1:
        if st.button("➕ Lançar Diárias e Passagens", use_container_width=True):
            dialog_diarias()
    with c2:
        if st.button("➕ Lançar Despesas Gerais", use_container_width=True):
            dialog_despesas()
