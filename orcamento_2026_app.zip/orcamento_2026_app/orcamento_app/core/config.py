"""
Configuração de caminhos do sistema.

IMPORTANTE: edite os caminhos abaixo para apontar para os arquivos no SEU
computador. Os três arquivos podem ficar todos na mesma pasta.

- BASES_XLSX: aba(s) fixas de referência (Datas, Plano de Contas, Projetos,
  SubProjetos, PCA2025, Lista de Contratos, Parâmetros Diária). Você edita
  esse arquivo livremente quando precisar atualizar uma base; o app relê
  sozinho sempre que detectar que o arquivo mudou (por data de modificação).

- ORCAMENTO_HISTORICO_XLSX: parte FIXA da tabela Orçamento (anos anteriores
  a 2026). Não é modificado pelo app.

- ORCAMENTO_2026_DB: banco SQLite que funciona como a "tabela auxiliar viva"
  do Orçamento 2026 — é nele que o app grava/exclui os lançamentos feitos
  pelas telas de Diárias/Passagens e Despesas Gerais, substituindo o que
  antes era feito pela macro.
"""
from pathlib import Path
import os

# Pasta onde ficam os arquivos de dados. Pode ser trocada por uma pasta
# do OneDrive/Google Drive sincronizada, se você quiser acessar de mais
# de um computador.
DATA_DIR = Path(os.environ.get("ORCAMENTO_DATA_DIR", Path(__file__).resolve().parent.parent / "data"))

BASES_XLSX = DATA_DIR / "bases.xlsx"
ORCAMENTO_HISTORICO_XLSX = DATA_DIR / "orcamento_historico.xlsx"
ORCAMENTO_2026_DB = DATA_DIR / "orcamento2026.db"

# Pasta de saída de PDFs/Excel gerados pelo app
EXPORT_DIR = DATA_DIR / "exportados"

ANO_ORCAMENTO = 2026
