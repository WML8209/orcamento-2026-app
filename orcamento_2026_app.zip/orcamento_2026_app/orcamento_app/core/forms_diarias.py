"""
Formulário de Diárias e Passagens (equivalente ao FormDepad).
Suporta edição: se indice_editar for passado, pré-carrega os valores do
lançamento e, ao salvar, substitui o lançamento antigo (mesmo índice).
"""
import streamlit as st
from core import loaders, calculos, db
from core.formatos import fmt_brl

LABELS = ["Funcionário", "Conselheiro", "Colaborador", "Colaborador Exame"]


def render_form_diarias(indice_editar: int | None = None):
    sufixo = f"_e{indice_editar}" if indice_editar else "_novo"

    meta = db.carregar_meta(indice_editar) if indice_editar else None
    p = meta["parametros"] if meta else {}
    cats_salvas = {c["categoria"]: c for c in p.get("categorias", [])}

    projetos_df = loaders.projetos()
    subprojetos_df = loaders.subprojetos()

    projetos_lista = projetos_df["Projeto"].tolist() if not projetos_df.empty else []
    subprojetos_lista = subprojetos_df["Código"].tolist() if not subprojetos_df.empty else []

    col1, col2 = st.columns(2)
    with col1:
        projeto = st.selectbox(
            "Projeto", options=projetos_lista, key=f"dlg_diarias_projeto{sufixo}",
            index=projetos_lista.index(p["projeto"]) if p.get("projeto") in projetos_lista else 0,
        )
    with col2:
        subprojeto = st.selectbox(
            "SubProjeto", options=subprojetos_lista, key=f"dlg_diarias_subprojeto{sufixo}",
            index=subprojetos_lista.index(p["subprojeto"]) if p.get("subprojeto") in subprojetos_lista else 0,
        )

    trechos = ["Nacional", "Internacional"]
    tipo_trecho = st.radio("Tipo de Trecho", trechos, horizontal=True, key=f"dlg_diarias_trecho{sufixo}",
                            index=trechos.index(p["tipo_trecho"]) if p.get("tipo_trecho") in trechos else 0)
    opcoes_incl = ["Somente Diária", "Diária e Passagem"]
    default_incl = opcoes_incl[1] if p.get("incluir_passagem") else opcoes_incl[0]
    incluir_passagem = st.radio(
        "Tipo de inclusão", opcoes_incl, horizontal=True, key=f"dlg_diarias_incl{sufixo}",
        index=opcoes_incl.index(default_incl) if p else 0,
    ) == "Diária e Passagem"

    st.markdown("**Classificações** — preencha uma ou mais categorias (deixe zerada a que não usar)")
    categorias_input = []
    cols = st.columns(4)
    for col, cat in zip(cols, LABELS):
        with col:
            st.markdown(f"**{cat}**")
            desabilita_exame_intl = cat == "Colaborador Exame" and tipo_trecho == "Internacional"
            if desabilita_exame_intl:
                st.caption("Não permitido p/ Internacional")
            salvo = cats_salvas.get(cat, {})
            qp = st.number_input("Pessoas", min_value=0.0, step=1.0, key=f"dlg_qp_{cat}{sufixo}",
                                  value=float(salvo.get("qtd_pessoas", 0.0)), disabled=desabilita_exame_intl)
            qr = st.number_input("Reuniões", min_value=0.0, step=1.0, key=f"dlg_qr_{cat}{sufixo}",
                                  value=float(salvo.get("qtd_reunioes", 0.0)), disabled=desabilita_exame_intl)
            qd = st.number_input("Diárias", min_value=0.0, step=0.5, key=f"dlg_qd_{cat}{sufixo}",
                                  value=float(salvo.get("qtd_diarias", 0.0)), disabled=desabilita_exame_intl)
            categorias_input.append(calculos.CategoriaInput(cat, qp, qr, qd))

    descricao = st.text_area("Descrição", key=f"dlg_diarias_desc{sufixo}", value=p.get("descricao", ""))

    if st.button("Calcular", key=f"dlg_diarias_calcular{sufixo}"):
        resultado = calculos.calcular_diarias_passagens(
            tipo_trecho, incluir_passagem, categorias_input, projeto, subprojeto, descricao
        )
        st.session_state[f"resultado_diarias{sufixo}"] = resultado
        st.session_state[f"resultado_diarias_ctx{sufixo}"] = dict(
            projeto=projeto, subprojeto=subprojeto, tipo_trecho=tipo_trecho,
            incluir_passagem=incluir_passagem, descricao=descricao,
            categorias=[{"categoria": c.categoria, "qtd_pessoas": c.qtd_pessoas,
                         "qtd_reunioes": c.qtd_reunioes, "qtd_diarias": c.qtd_diarias} for c in categorias_input],
        )
        for erro in resultado.erros:
            st.warning(erro)

    resultado = st.session_state.get(f"resultado_diarias{sufixo}")
    if resultado and resultado.linhas_orcamento:
        c1, c2, c3 = st.columns(3)
        c1.metric("Total Diária", fmt_brl(resultado.total_diaria))
        c2.metric("Total Passagem", fmt_brl(resultado.total_passagem))
        c3.metric("Auxílio Deslocamento", fmt_brl(resultado.total_auxilio))
        st.text_area("Memória de Cálculo", resultado.memoria, height=180, key=f"dlg_diarias_memoria{sufixo}")

        texto_botao = "💾 Salvar alterações" if indice_editar else "💾 Registrar lançamento"
        if st.button(texto_botao, type="primary", key=f"dlg_diarias_registrar{sufixo}"):
            if indice_editar:
                db.excluir_por_indice(indice_editar)
                indice = indice_editar
            else:
                indice = db.proximo_indice()
            for linha in resultado.linhas_orcamento:
                linha["indice"] = indice
                linha["data"] = "2026-01-01"
                linha["memoria_calculo"] = resultado.memoria
            db.inserir_linhas_orcamento(resultado.linhas_orcamento)
            db.salvar_meta(indice, "diarias", st.session_state[f"resultado_diarias_ctx{sufixo}"])
            st.success(f"{'Alterações salvas' if indice_editar else 'Registro(s) salvo(s)'} com sucesso!")
            del st.session_state[f"resultado_diarias{sufixo}"]
            if indice_editar:
                st.session_state.pop("editar_indice", None)
            st.rerun()
