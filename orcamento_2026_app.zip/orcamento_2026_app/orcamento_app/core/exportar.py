"""
Exportações:
  - gerar_pdf_memoria(): equivalente a GerarPDFMemoriaPorProjeto (VBA), um
    PDF por Projeto/SubProjeto com a memória de cálculo de diárias/passagens.
  - gerar_pdf_resumo(): PDF do resumo por Coordenadoria (aba 'Resumo').
  - gerar_excel_pca(): exporta a tabela PCA2026 para .xlsx.
"""
from pathlib import Path
from datetime import datetime
import pandas as pd
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

from core.config import EXPORT_DIR


def _styles():
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="TituloMemoria", fontSize=16, leading=20, alignment=1,
                               textColor=colors.HexColor("#002060"), spaceAfter=12, fontName="Helvetica-Bold"))
    styles.add(ParagraphStyle(name="Corpo", fontSize=11, leading=15))
    return styles


def gerar_pdf_memoria(indice: int, projeto: str, subprojeto: str, descricao: str, memoria: str) -> Path:
    EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    caminho = EXPORT_DIR / f"Memoria_{indice}.pdf"
    styles = _styles()
    doc = SimpleDocTemplate(str(caminho), pagesize=A4,
                             leftMargin=0.64 * cm, rightMargin=0.64 * cm,
                             topMargin=1.91 * cm, bottomMargin=1.91 * cm)
    story = [
        Paragraph("MEMÓRIA DE CÁLCULO - DIÁRIAS E PASSAGENS", styles["TituloMemoria"]),
        Spacer(1, 0.5 * cm),
        Paragraph(f"<b>Projeto:</b> {projeto}", styles["Corpo"]),
        Paragraph(f"<b>Subprojeto:</b> {subprojeto}", styles["Corpo"]),
        Spacer(1, 0.5 * cm),
        Paragraph(f"<b>Descrição:</b><br/>{descricao or '(sem descrição)'}".replace("\n", "<br/>"), styles["Corpo"]),
        Spacer(1, 0.5 * cm),
        Paragraph((memoria or "(sem memória de cálculo)").replace("\n", "<br/>"), styles["Corpo"]),
    ]
    doc.build(story)
    return caminho


def gerar_pdf_resumo(df_resumo: pd.DataFrame, coordenadoria: str, ano: int) -> Path:
    """df_resumo esperado com colunas: Projeto, Conta, Descricao, Total"""
    EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    caminho = EXPORT_DIR / f"Resumo_{coordenadoria}_{ano}.pdf"
    styles = _styles()
    doc = SimpleDocTemplate(str(caminho), pagesize=A4)
    story = [
        Paragraph(f"Elaboração do Orçamento de {ano} - Resumo", styles["TituloMemoria"]),
        Paragraph(f"Coordenadoria: {coordenadoria}", styles["Corpo"]),
        Spacer(1, 0.5 * cm),
    ]
    data = [list(df_resumo.columns)] + df_resumo.astype(str).values.tolist()
    tbl = Table(data, repeatRows=1)
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#002060")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    story.append(tbl)
    doc.build(story)
    return caminho


def gerar_excel_pca(df_pca: pd.DataFrame) -> Path:
    EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    caminho = EXPORT_DIR / f"PCA2026_{datetime.now():%Y%m%d_%H%M}.xlsx"
    with pd.ExcelWriter(caminho, engine="openpyxl") as writer:
        df_pca.to_excel(writer, sheet_name="PCA2026", index=False)
    return caminho
