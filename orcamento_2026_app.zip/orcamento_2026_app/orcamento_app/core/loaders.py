"""
Leitura das bases fixas a partir dos arquivos no computador da usuária.
Usa cache do Streamlit associado à data de modificação do arquivo: se o
arquivo não mudou, não relê do disco; se mudou, relê automaticamente na
próxima interação — sem precisar reiniciar o app.
"""
import streamlit as st
import pandas as pd
from pathlib import Path

from core.config import BASES_XLSX, ORCAMENTO_HISTORICO_XLSX


def _mtime(path: Path) -> float:
    return path.stat().st_mtime if path.exists() else 0.0


@st.cache_data(show_spinner=False)
def _read_sheet(path_str: str, sheet: str, mtime: float) -> pd.DataFrame:
    # `mtime` só existe como argumento para invalidar o cache quando o
    # arquivo muda; não é usado no corpo da função.
    return pd.read_excel(path_str, sheet_name=sheet)


def carregar_base(sheet: str) -> pd.DataFrame:
    if not BASES_XLSX.exists():
        st.error(f"Arquivo de bases não encontrado em: {BASES_XLSX}. Ajuste o caminho em core/config.py.")
        return pd.DataFrame()
    return _read_sheet(str(BASES_XLSX), sheet, _mtime(BASES_XLSX))


def datas() -> pd.DataFrame:
    return carregar_base("Datas")


def plano_de_contas() -> pd.DataFrame:
    return carregar_base("PlanoDeContas")


def contas_lancaveis() -> pd.DataFrame:
    """
    Só as contas 'folha' (nível de lançamento), com 11 dígitos no código —
    exclui contas de agrupamento como 'Execução da Despesa' (2 dígitos).
    """
    pc = plano_de_contas()
    if pc.empty:
        return pc
    pc = pc.copy()
    pc["ContaNorm"] = pc["Conta"].astype(str).str.replace(".", "", regex=False)
    return pc[pc["ContaNorm"].str.len() == 11]


def projetos() -> pd.DataFrame:
    return carregar_base("Projetos")


def subprojetos() -> pd.DataFrame:
    return carregar_base("SubProjetos")


def pca_2025() -> pd.DataFrame:
    return carregar_base("PCA2025")


def lista_contratos() -> pd.DataFrame:
    return carregar_base("ListaContratos")


def diario() -> pd.DataFrame:
    """Lançamentos contábeis (Débito/Crédito) usados para calcular o Executado."""
    return carregar_base("Diario")


@st.cache_data(show_spinner=False)
def _read_parametros_diaria(path_str: str, mtime: float) -> pd.DataFrame:
    # A aba tem 2 linhas de título antes do cabeçalho real (linha 4).
    return pd.read_excel(path_str, sheet_name="ParametrosDiaria", skiprows=3)


_CARGOS_VALIDOS = ["Funcionário", "Conselheiro", "Colaborador", "Colaborador Exame"]


def parametros_diaria() -> pd.DataFrame:
    """
    Lê a tabela de parâmetros (Cargo, Tipo Trecho, Valor Diária, Valor Passagem)
    que hoje já existe na planilha original documentada como fonte editável,
    em vez de repetir os valores fixos que estavam no código VBA.
    """
    if not BASES_XLSX.exists():
        return pd.DataFrame()
    df = _read_parametros_diaria(str(BASES_XLSX), _mtime(BASES_XLSX))
    # Mantém só as linhas de verdade da tabela (as linhas de rodapé — Auxílio
    # Deslocamento e Reajuste — caem na mesma coluna "Cargo" e precisam ser excluídas).
    return df[df["Cargo"].isin(_CARGOS_VALIDOS)]


@st.cache_data(show_spinner=False)
def _read_named_cell(path_str, sheet, row, col, mtime):
    import openpyxl
    wb = openpyxl.load_workbook(path_str, data_only=True)
    return wb[sheet].cell(row=row, column=col).value


def valor_auxilio_deslocamento():
    if not BASES_XLSX.exists():
        return 120.0
    v = _read_named_cell(str(BASES_XLSX), "ParametrosDiaria", 13, 2, _mtime(BASES_XLSX))
    return float(v) if v is not None else 120.0


def percentual_reajuste_renovacao():
    if not BASES_XLSX.exists():
        return 0.05
    v = _read_named_cell(str(BASES_XLSX), "ParametrosDiaria", 15, 2, _mtime(BASES_XLSX))
    return float(v) if v is not None else 0.05


def orcamento_historico() -> pd.DataFrame:
    if not ORCAMENTO_HISTORICO_XLSX.exists():
        st.warning(f"Histórico não encontrado em: {ORCAMENTO_HISTORICO_XLSX}.")
        return pd.DataFrame()
    return _read_sheet(str(ORCAMENTO_HISTORICO_XLSX), "Orcamento", _mtime(ORCAMENTO_HISTORICO_XLSX))
