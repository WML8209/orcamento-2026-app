"""
Formulário de Despesas Gerais (equivalente ao FormDespesasGerais).
Suporta edição: se indice_editar for passado, pré-carrega os valores do
lançamento e, ao salvar, substitui o lançamento antigo (mesmo índice).
"""
from datetime import date
import streamlit as st
from core import loaders, calculos, db
from core.formatos import fmt_brl, parse_valor_br


def render_form_despesas(indice_editar: int | None = None):
    sufixo = f"_e{indice_editar}" if indice_editar else "_novo"

    meta = db.carregar_meta(indice_editar) if indice_editar else None
    p = meta["parametros"] if meta else {}

    projetos_df = loaders.projetos()
    subprojetos_df = loaders.subprojetos()
    plano_df = loaders.contas_lancaveis()
    pca_antigo_df = loaders.pca_2025()

    tipos = ["Nova Contratação", "Renovação", "Sem Renovação", "Demais Despesas"]
    tipo = st.radio("Tipo", tipos, horizontal=True, key=f"dlg_desp_tipo{sufixo}",
                     index=tipos.index(p["tipo"]) if p.get("tipo") in tipos else 0)

    projetos_lista = projetos_df["Projeto"].tolist() if not projetos_df.empty else []
    subprojetos_lista = subprojetos_df["Código"].tolist() if not subprojetos_df.empty else []
    contas_lista = plano_df["Descrição"].tolist() if not plano_df.empty else []

    col1, col2, col3 = st.columns(3)
    with col1:
        projeto = st.selectbox("Projeto", options=projetos_lista, key=f"dlg_desp_projeto{sufixo}",
                                index=projetos_lista.index(p["projeto"]) if p.get("projeto") in projetos_lista else 0)
    with col2:
        subprojeto = st.selectbox("SubProjeto", options=subprojetos_lista, key=f"dlg_desp_subprojeto{sufixo}",
                                   index=subprojetos_lista.index(p["subprojeto"]) if p.get("subprojeto") in subprojetos_lista else 0)
    with col3:
        conta_desc = st.selectbox("Conta", options=contas_lista, key=f"dlg_desp_conta{sufixo}",
                                   index=contas_lista.index(p["conta_desc"]) if p.get("conta_desc") in contas_lista else 0)

    descricao = st.text_area("Descrição do Objeto", key=f"dlg_desp_descricao{sufixo}", value=p.get("descricao", ""))

    valor_total = None
    inicio = fim = None
    mes_antigo = mes_novo = 0
    valor_diferente = None

    if tipo == "Nova Contratação":
        c1, c2, c3 = st.columns(3)
        inicio = c1.date_input("Início da Vigência", value=_parse_iso(p.get("inicio"), date(2026, 1, 1)),
                                format="DD/MM/YYYY", key=f"dlg_desp_inicio{sufixo}")
        fim = c2.date_input("Fim da Vigência", value=_parse_iso(p.get("fim"), date(2026, 12, 31)),
                             format="DD/MM/YYYY", key=f"dlg_desp_fim{sufixo}")
        valor_total_txt = c3.text_input("Valor Total da Contratação (R$)", key=f"dlg_desp_valor{sufixo}",
                                         value=_fmt_edit(p.get("valor_total")), placeholder="0,00")
        valor_total = parse_valor_br(valor_total_txt)

    elif tipo in ("Renovação", "Sem Renovação"):
        st.caption("Selecione o fornecedor para pré-carregar os dados do PCA2025.")
        fornecedores = pca_antigo_df["Favorecido"].dropna().unique().tolist() if not pca_antigo_df.empty else []
        opcoes_forn = [""] + fornecedores
        fornecedor = st.selectbox("Fornecedor (PCA2025)", options=opcoes_forn, key=f"dlg_desp_fornecedor{sufixo}",
                                   index=opcoes_forn.index(p["fornecedor"]) if p.get("fornecedor") in opcoes_forn else 0)
        linha_pca = None
        if fornecedor and not pca_antigo_df.empty:
            achou = pca_antigo_df[pca_antigo_df["Favorecido"] == fornecedor]
            if not achou.empty:
                linha_pca = achou.iloc[0]
        c1, c2, c3 = st.columns(3)
        default_inicio = _parse_iso(p.get("inicio")) or (linha_pca["Início da Vigência"].date() if linha_pca is not None else date(2025, 1, 1))
        default_fim = _parse_iso(p.get("fim")) or (linha_pca["Fim da Vigência"].date() if linha_pca is not None else date(2026, 12, 31))
        inicio = c1.date_input("Início da Vigência", value=default_inicio, format="DD/MM/YYYY", key=f"dlg_desp_inicio2{sufixo}")
        fim = c2.date_input("Fim da Vigência", value=default_fim, format="DD/MM/YYYY", key=f"dlg_desp_fim2{sufixo}")
        default_valor = p.get("valor_total") if p.get("valor_total") is not None else (float(linha_pca["Valor Total"]) if linha_pca is not None else None)
        valor_total_txt = c3.text_input("Valor Total (R$)", key=f"dlg_desp_valor2{sufixo}",
                                         value=_fmt_edit(default_valor), placeholder="0,00")
        valor_total = parse_valor_br(valor_total_txt)
        c4, c5 = st.columns(2)
        mes_antigo = c4.number_input("Meses com valor antigo dentro de 2026", min_value=0, step=1,
                                      key=f"dlg_desp_mesantigo{sufixo}", value=int(p.get("mes_antigo", 0)))
        if tipo == "Renovação":
            mes_novo = c5.number_input("Meses com valor novo (pós-renovação) dentro de 2026", min_value=0, step=1,
                                        key=f"dlg_desp_mesnovo{sufixo}", value=int(p.get("mes_novo", 0)))

    elif tipo == "Demais Despesas":
        st.info("Preencha apenas Projeto, SubProjeto, Conta e o valor proporcional do exercício.")
        valor_dif_txt = st.text_input("Valor Proporcional do Exercício (R$)", key=f"dlg_desp_valordif0{sufixo}",
                                       value=_fmt_edit(p.get("valor_diferente")), placeholder="0,00")
        valor_diferente = parse_valor_br(valor_dif_txt)

    usar_valor_diferente = False
    if tipo != "Demais Despesas":
        usar_valor_diferente = st.checkbox("Usar valor diferente do calculado (Valor Diferente)",
                                            key=f"dlg_desp_usardif{sufixo}", value=bool(p.get("usar_valor_diferente", False)))
        if usar_valor_diferente:
            valor_dif_txt = st.text_input("Valor Diferente (R$)", key=f"dlg_desp_valordif{sufixo}",
                                           value=_fmt_edit(p.get("valor_diferente")), placeholder="0,00")
            valor_diferente = parse_valor_br(valor_dif_txt)
        else:
            valor_diferente = None

    if st.button("Calcular", key=f"dlg_desp_calcular{sufixo}"):
        resultado = calculos.calcular_despesas_gerais(
            tipo, valor_total, inicio, fim, mes_antigo, mes_novo,
            valor_diferente=valor_diferente if (tipo == "Demais Despesas" or usar_valor_diferente) else None,
        )
        st.session_state[f"resultado_despesa{sufixo}"] = resultado
        st.session_state[f"resultado_despesa_ctx{sufixo}"] = dict(
            tipo=tipo, projeto=projeto, subprojeto=subprojeto, conta_desc=conta_desc,
            descricao=descricao, inicio=inicio, fim=fim,
            fornecedor=st.session_state.get(f"dlg_desp_fornecedor{sufixo}"),
            mes_antigo=mes_antigo, mes_novo=mes_novo,
            usar_valor_diferente=usar_valor_diferente, valor_diferente=valor_diferente,
            valor_total=valor_total,
        )

    resultado = st.session_state.get(f"resultado_despesa{sufixo}")
    if resultado:
        if resultado.erro:
            st.error(resultado.erro)
        else:
            c1, c2, c3 = st.columns(3)
            c1.metric("Valor Proporcional", fmt_brl(resultado.valor_proporcional))
            c2.metric("Valor Após Renovação", fmt_brl(resultado.valor_apos_renovacao))
            c3.metric("Valor Total a Registrar", fmt_brl(resultado.valor_total))

            texto_botao = "💾 Salvar alterações" if indice_editar else "💾 Registrar lançamento"
            if st.button(texto_botao, type="primary", key=f"dlg_desp_registrar{sufixo}"):
                ctx = st.session_state[f"resultado_despesa_ctx{sufixo}"]
                conta_row = plano_df[plano_df["Descrição"] == ctx["conta_desc"]]
                cod_conta = str(conta_row.iloc[0]["Conta"]).replace(".", "") if not conta_row.empty else ""

                if indice_editar:
                    db.excluir_por_indice(indice_editar)
                    indice = indice_editar
                else:
                    indice = db.proximo_indice()

                db.inserir_linhas_orcamento([{
                    "indice": indice, "projeto": ctx["projeto"], "subprojeto": ctx["subprojeto"],
                    "conta": cod_conta, "valor": resultado.valor_total, "data": "2026-01-01",
                    "descricao": ctx["descricao"], "memoria_calculo": None, "origem": "despesas_gerais",
                }])

                if ctx["tipo"] in ("Nova Contratação", "Renovação", "Sem Renovação"):
                    item = db.proximo_item_pca()
                    db.inserir_pca({
                        "indice_orcamento": indice, "item": item, "descricao_objeto": ctx["descricao"],
                        "justificativa": None, "contratacao_renovacao": ctx["tipo"],
                        "data_contratacao_renovacao": str(ctx["inicio"]) if ctx["inicio"] else None,
                        "valor_contratacao_renovacao": None, "valor_orcamento_2026": resultado.valor_total,
                        "grau_prioridade": None, "classificacao": None, "conta_contabil": cod_conta,
                        "descricao": ctx["conta_desc"], "projeto": ctx["projeto"], "uo": ctx["subprojeto"],
                        "diferenca": 0, "observacao_decont": "N/A",
                        "mes": ctx["inicio"].month if ctx["inicio"] else None,
                        "data_pca": ctx["inicio"].month if ctx["inicio"] else None,
                    })

                db.salvar_meta(indice, "despesas_gerais", ctx)
                st.success(f"{'Alterações salvas' if indice_editar else 'Registro concluído'} com sucesso!")
                del st.session_state[f"resultado_despesa{sufixo}"]
                if indice_editar:
                    st.session_state.pop("editar_indice", None)
                st.rerun()


def _fmt_edit(valor):
    from core.formatos import fmt_num_br
    return fmt_num_br(valor) if valor is not None else ""


def _parse_iso(texto, default=None):
    if not texto:
        return default
    try:
        return date.fromisoformat(str(texto)[:10])
    except ValueError:
        return default
