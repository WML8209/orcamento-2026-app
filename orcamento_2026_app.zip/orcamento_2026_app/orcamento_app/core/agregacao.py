"""
Monta a visão "Projeção Orçamento 2026" juntando:
  - orcamento_historico.xlsx  (anos <= 2025, fixo)
  - banco SQLite orcamento_2026 (lançamentos feitos pelo app)
e enriquecendo com descrição de conta (Plano de Contas), nome do
subprojeto/coordenadoria (SubProjetos) e nome do projeto (Projetos).

Executado: calculado a partir da aba Diário (bases.xlsx), regra confirmada
com a Ana — D/C == 'D' soma, D/C == 'C' diminui — agrupado por
Projeto/SubProjeto/Conta/Ano. Ver _executado_map().
"""
import pandas as pd

from core import loaders, db


def _plano_contas_map() -> dict:
    pc = loaders.plano_de_contas()
    if pc.empty:
        return {}
    pc = pc.copy()
    pc["ContaNorm"] = pc["Conta"].astype(str).str.replace(".", "", regex=False)
    return dict(zip(pc["ContaNorm"], pc["Descrição"]))


def _subprojeto_map() -> pd.DataFrame:
    sp = loaders.subprojetos()
    if sp.empty:
        return sp
    return sp[["SubProjeto", "Nome", "Coordenadoria", "Sigla"]].copy()


def _projeto_map() -> pd.DataFrame:
    pj = loaders.projetos()
    if pj.empty:
        return pj
    out = pj[["Código", "Área Responsável", "Projeto"]].rename(
        columns={"Código": "ProjetoCodigo", "Projeto": "ProjetoLabel"}
    )
    return out


def montar_orcamento_completo() -> pd.DataFrame:
    """Retorna o Orçamento (histórico + 2026 vivo) em formato tidy, já com
    descrições de conta, subprojeto/coordenadoria e projeto."""
    hist = loaders.orcamento_historico()
    if not hist.empty:
        hist = hist.rename(columns={
            "Orçamento Atualizado": "Valor", "Ano": "AnoRaw",
            "Memória de Cálculo": "MemoriaCalculo", "Índice": "Indice",
        })
        hist["Ano"] = pd.to_datetime(hist["AnoRaw"]).dt.year
        hist = hist[["Projeto", "SubProjeto", "Conta", "Valor", "Ano", "Descrição", "MemoriaCalculo", "Indice"]]

    vivo = db.carregar_orcamento_2026()
    if not vivo.empty:
        vivo = vivo.rename(columns={
            "projeto": "Projeto", "subprojeto": "SubProjeto", "conta": "Conta",
            "valor": "Valor", "descricao": "Descrição", "memoria_calculo": "MemoriaCalculo",
            "indice": "Indice",
        })
        vivo["Ano"] = 2026
        vivo = vivo[["Projeto", "SubProjeto", "Conta", "Valor", "Ano", "Descrição", "MemoriaCalculo", "Indice"]]

    partes = [df for df in (hist, vivo) if not df.empty]
    if not partes:
        return pd.DataFrame(columns=["Projeto", "SubProjeto", "Conta", "Valor", "Ano", "Descrição", "MemoriaCalculo", "Indice"])

    completo = pd.concat(partes, ignore_index=True)

    # Enriquecer com descrição de conta
    mapa_contas = _plano_contas_map()
    completo["ContaNorm"] = completo["Conta"].astype(str).str.replace(".", "", regex=False)
    completo["ContaDescricao"] = completo["ContaNorm"].map(mapa_contas).fillna(completo["Conta"].astype(str))

    # Enriquecer com Coordenadoria via SubProjeto
    sp = _subprojeto_map()
    if not sp.empty:
        completo["SubProjeto"] = completo["SubProjeto"].astype(str)
        sp["SubProjeto"] = sp["SubProjeto"].astype(str)
        completo = completo.merge(sp, on="SubProjeto", how="left")

    # Enriquecer com descrição do projeto
    pj = _projeto_map()
    if not pj.empty:
        completo["Projeto"] = completo["Projeto"].astype(str)
        pj["ProjetoCodigo"] = pj["ProjetoCodigo"].astype(str)
        completo = completo.merge(pj, left_on="Projeto", right_on="ProjetoCodigo", how="left")

    return completo


def tabela_dinamica_projecao(completo: pd.DataFrame, coordenadoria: str | None = None) -> pd.DataFrame:
    """Equivalente à PivotTable 'Orçamento26': Coordenadoria > Projeto > SubProjeto > Conta, colunas = Ano."""
    df = completo.copy()
    if coordenadoria and coordenadoria != "(Todas)":
        df = df[df["Coordenadoria"] == coordenadoria]
    if df.empty:
        return df
    pivot = pd.pivot_table(
        df, index=["Coordenadoria", "Projeto", "SubProjeto", "ContaDescricao"],
        columns="Ano", values="Valor", aggfunc="sum", fill_value=0,
    )
    pivot["Total"] = pivot.sum(axis=1)
    return pivot.reset_index()


def coordenadorias_disponiveis(completo: pd.DataFrame) -> list:
    if completo.empty or "Coordenadoria" not in completo.columns:
        return []
    return sorted([c for c in completo["Coordenadoria"].dropna().unique().tolist()])


def anos_disponiveis(completo: pd.DataFrame) -> list:
    if completo.empty or "Ano" not in completo.columns:
        return []
    return sorted(completo["Ano"].dropna().unique().tolist())


def montar_arvore_multi_ano(completo: pd.DataFrame, coordenadoria: str, anos: list) -> dict:
    """
    Monta a árvore Projeto > SubProjeto > Conta com Orçamento Atualizado e
    Executado lado a lado PARA CADA ANO — equivalente à tabela dinâmica
    'Orçamento26' da planilha original (2023 | 2024 | 2025 | 2026, cada um
    com Orçamento Atualizado / Executado).
    """
    df = completo[completo["Coordenadoria"] == coordenadoria].copy()
    arvore = {"anos": anos, "projetos": [], "totais": {a: {"orcamento": 0.0, "execucao": 0.0} for a in anos}}
    if df.empty:
        return arvore

    exec_maps = {a: _executado_map(a) for a in anos}

    for proj_cod, df_proj in df.groupby("Projeto"):
        descricao_proj = df_proj["ProjetoLabel"].iloc[0] if "ProjetoLabel" in df_proj.columns and pd.notna(df_proj["ProjetoLabel"].iloc[0]) else proj_cod
        subprojetos = []
        for sub_cod, df_sub in df_proj.groupby("SubProjeto"):
            nome_sub = df_sub["Nome"].iloc[0] if "Nome" in df_sub.columns and pd.notna(df_sub["Nome"].iloc[0]) else sub_cod
            contas_keys = df_sub[["ContaDescricao", "ContaNorm"]].drop_duplicates()
            contas = []
            sub_tot = {a: {"orcamento": 0.0, "execucao": 0.0} for a in anos}
            for _, row in contas_keys.iterrows():
                conta_desc, conta_norm = row["ContaDescricao"], row["ContaNorm"]
                valores = {}
                for a in anos:
                    orc = df_sub[(df_sub["ContaNorm"] == conta_norm) & (df_sub["Ano"] == a)]["Valor"].sum()
                    exec_ = exec_maps[a].get((str(proj_cod), str(sub_cod), conta_norm)) or 0.0
                    valores[a] = {"orcamento": float(orc), "execucao": float(exec_)}
                    sub_tot[a]["orcamento"] += valores[a]["orcamento"]
                    sub_tot[a]["execucao"] += valores[a]["execucao"]
                contas.append({"conta": conta_desc, "valores": valores})
            subprojetos.append({"subprojeto": sub_cod, "nome": nome_sub, "contas": contas, "totais": sub_tot})

        proj_tot = {a: {
            "orcamento": sum(s["totais"][a]["orcamento"] for s in subprojetos),
            "execucao": sum(s["totais"][a]["execucao"] for s in subprojetos),
        } for a in anos}
        arvore["projetos"].append({
            "projeto": proj_cod, "descricao": descricao_proj,
            "subprojetos": subprojetos, "totais": proj_tot,
        })

    for a in anos:
        arvore["totais"][a]["orcamento"] = sum(p["totais"][a]["orcamento"] for p in arvore["projetos"])
        arvore["totais"][a]["execucao"] = sum(p["totais"][a]["execucao"] for p in arvore["projetos"])
    return arvore


def _executado_map(ano: int) -> dict:
    """
    (Projeto, SubProjeto, ContaNorm) -> valor executado no ano.
    Regra confirmada: D/C == 'D' soma, D/C == 'C' diminui.
    """
    dia = loaders.diario()
    if dia.empty:
        return {}
    dia = dia.copy()
    dia["DataLanc"] = pd.to_datetime(dia["Data Lançamento"], dayfirst=True, errors="coerce")
    dia["Ano"] = dia["DataLanc"].dt.year
    dia = dia[dia["Ano"] == ano]
    if dia.empty:
        return {}
    dia["Sinal"] = dia["D/C"].map({"D": 1, "C": -1}).fillna(0)
    dia["ValorAssinado"] = dia["Valor"] * dia["Sinal"]
    dia["ContaNorm"] = dia["Conta"].astype(str).str.replace(".", "", regex=False)
    dia["Projeto"] = dia["Projeto"].astype(str)
    dia["SubProjeto"] = dia["SubProjeto"].astype(str)
    agrupado = dia.groupby(["Projeto", "SubProjeto", "ContaNorm"])["ValorAssinado"].sum()
    return agrupado.to_dict()


def montar_arvore_projecao(completo: pd.DataFrame, coordenadoria: str, ano: int) -> dict:
    """
    Monta a estrutura hierárquica Projeto > SubProjeto > Conta para a tela de
    Projeção em formato árvore (expandir/recolher), já filtrada por
    Coordenadoria e Ano, com Orçamento e Execução lado a lado.
    """
    df = completo[(completo["Coordenadoria"] == coordenadoria) & (completo["Ano"] == ano)].copy()
    arvore = {"projetos": [], "total_orcamento": 0.0, "total_execucao": 0.0}
    if df.empty:
        return arvore

    exec_map = _executado_map(ano)

    for proj_cod, df_proj in df.groupby("Projeto"):
        descricao_proj = df_proj["ProjetoLabel"].iloc[0] if "ProjetoLabel" in df_proj.columns and pd.notna(df_proj["ProjetoLabel"].iloc[0]) else proj_cod
        subprojetos = []
        for sub_cod, df_sub in df_proj.groupby("SubProjeto"):
            nome_sub = df_sub["Nome"].iloc[0] if "Nome" in df_sub.columns and pd.notna(df_sub["Nome"].iloc[0]) else sub_cod
            contas = (
                df_sub.groupby(["ContaDescricao", "ContaNorm"])["Valor"].sum().reset_index()
                .rename(columns={"ContaDescricao": "conta", "Valor": "orcamento"})
            )
            contas["execucao"] = contas["ContaNorm"].apply(
                lambda cn: exec_map.get((str(proj_cod), str(sub_cod), cn))
            )
            subtotal_orc = float(contas["orcamento"].sum())
            subtotal_exec = float(contas["execucao"].dropna().sum())
            subprojetos.append({
                "subprojeto": sub_cod, "nome": nome_sub,
                "contas": contas.drop(columns=["ContaNorm"]).to_dict("records"),
                "subtotal_orcamento": subtotal_orc, "subtotal_execucao": subtotal_exec,
            })
        subtotal_proj = sum(s["subtotal_orcamento"] for s in subprojetos)
        subtotal_proj_exec = sum(s["subtotal_execucao"] for s in subprojetos)
        arvore["projetos"].append({
            "projeto": proj_cod, "descricao": descricao_proj,
            "subprojetos": subprojetos,
            "subtotal_orcamento": subtotal_proj, "subtotal_execucao": subtotal_proj_exec,
        })

    arvore["total_orcamento"] = sum(p["subtotal_orcamento"] for p in arvore["projetos"])
    arvore["total_execucao"] = sum(p["subtotal_execucao"] for p in arvore["projetos"])
    return arvore


def resumo_por_coordenadoria(completo: pd.DataFrame, ano: int, coordenadoria: str | None = None) -> pd.DataFrame:
    df = completo[completo["Ano"] == ano].copy()
    if coordenadoria and coordenadoria != "(Todas)":
        df = df[df["Coordenadoria"] == coordenadoria]
    if df.empty:
        return df
    agrupado = (
        df.groupby(["Projeto", "SubProjeto", "Descrição", "ContaDescricao"], dropna=False)["Valor"]
        .sum().reset_index().rename(columns={"ContaDescricao": "Conta", "Valor": "Total"})
    )
    return agrupado.sort_values(["Projeto", "SubProjeto"])
