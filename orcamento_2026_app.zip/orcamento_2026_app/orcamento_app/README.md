# Sistema de Elaboração do Orçamento 2026

Substitui as macros VBA da planilha `Proposta_Orçamentária_2026.xlsb` por um
app local (Streamlit) que roda no seu computador e lê/grava os arquivos de
dados automaticamente — sem precisar abrir o Excel nem fazer upload manual.

## Instalação (uma vez só)

1. Instale o [Python 3.11+](https://www.python.org/downloads/) (marque "Add to PATH" no instalador do Windows).
2. Abra um terminal (PowerShell/Prompt de Comando) nesta pasta e rode:

```
pip install -r requirements.txt
```

## Rodar o sistema

```
streamlit run Home.py
```

Isso abre automaticamente uma aba no seu navegador (endereço tipo
`http://localhost:8501`). É o app "rodando" — pode deixar o terminal aberto
enquanto usa. Para fechar, feche o terminal ou aperte `Ctrl+C`.

## Onde ficam os dados

Tudo dentro da pasta `data/`:

| Arquivo | O que é | Como atualizar |
|---|---|---|
| `bases.xlsx` | Abas fixas: Datas, PlanoDeContas, Projetos, SubProjetos, PCA2025, ListaContratos, ParametrosDiaria, Diario | Edite direto no Excel e salve. O app relê sozinho na próxima ação. |
| `orcamento_historico.xlsx` | Orçamento fixo de anos anteriores a 2026 | Só mude se precisar corrigir histórico. |
| `orcamento2026.db` | Banco SQLite — é a "tabela viva" do Orçamento 2026, alimentada pelas telas de lançamento | **Não edite manualmente.** É gerada e mantida pelo próprio app. |
| `exportados/` | PDFs e Excel gerados pelo app (memórias de cálculo, resumo, PCA2026) | Criada automaticamente. |

Os dados que vieram junto (Projeto "5008 - PROJETO TESTE" etc.) são os
mesmos dados de teste que já estavam na sua planilha original — substitua
o conteúdo de `bases.xlsx` e `orcamento_historico.xlsx` pelos dados reais
quando for usar de verdade.

Se quiser acessar de mais de um computador (ex. notebook + PC), mova a
pasta `data/` inteira para uma pasta sincronizada (OneDrive, Google Drive)
e aponte `ORCAMENTO_DATA_DIR` (variável de ambiente) ou edite
`core/config.py` para esse caminho.

## O que cada tela faz (equivalência com a planilha original)

| Tela | Equivale a |
|---|---|
| Lançar Diárias e Passagens | Formulário `FormDepad` (aba MultiPage 1) |
| Lançar Despesas Gerais | Formulário `FormDespesasGerais` (Contratação/Renovação/Sem Renovação/Demais Despesas) |
| Projeção Orçamento 2026 | Tabela dinâmica `Orçamento26` (histórico + 2026 combinados) |
| Resumo | Aba `Resumo`, com exportação em PDF (equivalente a `GerarPDFMemoriaPorProjeto`) |
| PCA 2026 | Aba `PCA2026`, com exportação em Excel |

## Cálculo do Executado

A coluna **Execução do Ano**, na tela de Projeção, vem da aba **Diario**
(dentro de `bases.xlsx`), somando/subtraindo pelos lançamentos de
Débito/Crédito de cada Projeto/SubProjeto/Conta no ano: **D soma, C diminui**
(regra confirmada). Se algum lançamento não tiver D/C preenchido corretamente,
ele é ignorado nessa soma — vale conferir a aba Diario se algum total parecer
estranho.

## Estrutura do código

```
Home.py                          -> tela inicial
pages/
  1_Lançar_Diárias_e_Passagens.py
  2_Lançar_Despesas_Gerais.py
  3_Projeção_Orçamento_2026.py
  4_Resumo.py
  5_PCA_2026.py
core/
  config.py       -> caminhos dos arquivos (edite aqui se mudar a pasta de dados)
  loaders.py       -> leitura das bases fixas (com autoatualização por data do arquivo)
  db.py            -> banco SQLite (a "tabela viva" do Orçamento 2026)
  calculos.py      -> réplica das regras de cálculo das duas macros originais
  agregacao.py     -> monta a Projeção (histórico + vivo) e o Resumo
  exportar.py      -> geração de PDF e Excel
data/              -> seus arquivos de dados (ver tabela acima)
```
